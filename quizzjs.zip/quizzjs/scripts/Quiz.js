export class Quiz{
    constructor(title, description, answers, ques){
        this.title = title;
        this.description = description;
        this.ques = []
        this.answers = {}
    }
}
